"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.falsePositiveStore = exports.FalsePositiveStore = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
// Determine root directory (handle pkg vs dev)
const isPkg = process.pkg;
const ROOT_DIR = isPkg ? path_1.default.dirname(process.execPath) : path_1.default.join(__dirname, '../../');
const FP_FILE = path_1.default.join(ROOT_DIR, 'falsePositives.json');
class FalsePositiveStore {
    constructor() {
        this.examples = [];
        this.load();
    }
    add(message) {
        if (!this.examples.includes(message)) {
            this.examples.push(message);
            this.save();
        }
    }
    getAll() {
        return this.examples;
    }
    load() {
        if (fs_1.default.existsSync(FP_FILE)) {
            try {
                const raw = fs_1.default.readFileSync(FP_FILE, 'utf-8');
                this.examples = JSON.parse(raw);
            }
            catch (e) {
                console.error('Failed to load falsePositives.json', e);
            }
        }
    }
    save() {
        try {
            fs_1.default.writeFileSync(FP_FILE, JSON.stringify(this.examples, null, 2));
        }
        catch (e) {
            console.error('Failed to save falsePositives.json', e);
        }
    }
}
exports.FalsePositiveStore = FalsePositiveStore;
exports.falsePositiveStore = new FalsePositiveStore();
