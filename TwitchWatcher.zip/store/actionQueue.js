"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.actionQueue = exports.ActionQueue = void 0;
class ActionQueue {
    constructor() {
        this.queue = [];
    }
    add(action) {
        this.queue.push(action);
    }
    getPending() {
        return this.queue.filter(a => a.status === 'pending');
    }
    resolve(id, resolution) {
        const idx = this.queue.findIndex(a => a.id === id);
        if (idx !== -1) {
            this.queue[idx].status = resolution;
            // Optionally clean up processed items after some time
        }
    }
    get(id) {
        return this.queue.find(a => a.id === id);
    }
}
exports.ActionQueue = ActionQueue;
exports.actionQueue = new ActionQueue();
