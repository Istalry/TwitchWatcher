"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsStore = exports.SettingsStore = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const crypto_1 = __importDefault(require("crypto"));
const os_1 = __importDefault(require("os"));
// Check if running inside pkg (compiled executable)
const isPkg = process.pkg;
const ROOT_DIR = isPkg ? path_1.default.dirname(process.execPath) : path_1.default.join(__dirname, '../../');
const SETTINGS_FILE = path_1.default.join(ROOT_DIR, 'settings.json');
const ALGORITHM = 'aes-256-gcm';
const DEFAULT_SETTINGS = {
    isSetupComplete: false,
    aiLanguage: 'English',
    defaultTimeoutDuration: 600,
    twitch: {
        username: '',
        channel: '',
        clientId: '',
        clientSecret: '',
    },
    ai: {
        provider: 'ollama',
        model: 'gemma3:4b',
    },
};
class SettingsStore {
    constructor() {
        this.encryptionKey = this.deriveMachineKey();
        this.settings = this.load();
    }
    deriveMachineKey() {
        // Machine-bound key derivation: specific to Hostname + Username
        const machineId = `${os_1.default.hostname()}-${os_1.default.userInfo().username}`;
        const salt = 'TwitchWatcher-Secure-Salt'; // Static salt is fine here as we rely on machine uniqueness
        return crypto_1.default.pbkdf2Sync(machineId, salt, 100000, 32, 'sha256');
    }
    encrypt(text) {
        const iv = crypto_1.default.randomBytes(16);
        const cipher = crypto_1.default.createCipheriv(ALGORITHM, this.encryptionKey, iv);
        let encrypted = cipher.update(text, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return {
            iv: iv.toString('hex'),
            content: encrypted,
            authTag: cipher.getAuthTag().toString('hex'),
        };
    }
    decrypt(data) {
        const iv = Buffer.from(data.iv, 'hex');
        const authTag = Buffer.from(data.authTag, 'hex');
        const decipher = crypto_1.default.createDecipheriv(ALGORITHM, this.encryptionKey, iv);
        decipher.setAuthTag(authTag);
        let decrypted = decipher.update(data.content, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    }
    get() {
        return JSON.parse(JSON.stringify(this.settings));
    }
    update(partial) {
        if (typeof partial === 'function') {
            const updates = partial(this.settings);
            this.settings = Object.assign(Object.assign({}, this.settings), updates);
        }
        else {
            this.settings = Object.assign(Object.assign({}, this.settings), partial);
        }
        this.save();
    }
    // Specific updaters for nested objects to make usage easier
    updateTwitch(updates) {
        this.settings.twitch = Object.assign(Object.assign({}, this.settings.twitch), updates);
        this.save();
    }
    updateAI(updates) {
        this.settings.ai = Object.assign(Object.assign({}, this.settings.ai), updates);
        this.save();
    }
    load() {
        if (fs_1.default.existsSync(SETTINGS_FILE)) {
            try {
                const raw = fs_1.default.readFileSync(SETTINGS_FILE, 'utf-8');
                const parsed = JSON.parse(raw);
                // Check if file is encrypted (has encryption fields)
                if (parsed.iv && parsed.content && parsed.authTag) {
                    try {
                        const decryptedJson = this.decrypt(parsed);
                        return Object.assign(Object.assign({}, DEFAULT_SETTINGS), JSON.parse(decryptedJson));
                    }
                    catch (e) {
                        console.error('Failed to decrypt settings.json. Machine signature mismatch?');
                        // Return default, forcing re-setup if key implies different machine
                        return Object.assign({}, DEFAULT_SETTINGS);
                    }
                }
                else {
                    // Migration: Handle plain JSON if it exists from previous version
                    // We will save it encrypted immediately after loading
                    const migrated = Object.assign(Object.assign({}, DEFAULT_SETTINGS), parsed);
                    this.settings = migrated; // Set temporarily so save works
                    this.save();
                    return migrated;
                }
            }
            catch (e) {
                console.error('Failed to load settings.json', e);
            }
        }
        return Object.assign({}, DEFAULT_SETTINGS);
    }
    save() {
        try {
            const jsonStr = JSON.stringify(this.settings);
            const encrypted = this.encrypt(jsonStr);
            fs_1.default.writeFileSync(SETTINGS_FILE, JSON.stringify(encrypted, null, 2));
        }
        catch (e) {
            console.error('Failed to save settings.json', e);
        }
    }
}
exports.SettingsStore = SettingsStore;
exports.settingsStore = new SettingsStore();
