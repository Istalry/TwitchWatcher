"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const readline_1 = __importDefault(require("readline"));
const rl = readline_1.default.createInterface({
    input: process.stdin,
    output: process.stdout
});
const ENV_PATH = path_1.default.join(__dirname, '../../.env');
const question = (query) => {
    return new Promise((resolve) => rl.question(query, resolve));
};
const setup = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('\n=== Twitch Auto-Moderator Setup ===\n');
    let currentConfig = {};
    if (fs_1.default.existsSync(ENV_PATH)) {
        console.log('Refining existing .env configuration...');
        const envContent = fs_1.default.readFileSync(ENV_PATH, 'utf-8');
        envContent.split('\n').forEach(line => {
            const [key, value] = line.split('=');
            if (key && value)
                currentConfig[key.trim()] = value.trim();
        });
    }
    else {
        console.log('Creating new configuration...');
    }
    console.log('\n--- Twitch Credentials ---');
    console.log('You will need to create an Application on the Twitch Developer Console.');
    console.log('1. Go to https://dev.twitch.tv/console/apps/create');
    console.log('2. Name: e.g. "My AutoMod Bot"');
    console.log('3. OAuth Redirect URLs: http://localhost:3000/auth/twitch/callback');
    console.log('4. Category: Chat Bot');
    console.log('5. Create and copy Client ID and Client Secret.');
    console.log('--------------------------\n');
    const username = (yield question(`Twitch Bot Username (${currentConfig.TWITCH_USERNAME || ''}): `)) || currentConfig.TWITCH_USERNAME;
    const channel = (yield question(`Target Channel to Moderate (${currentConfig.TWITCH_CHANNEL || ''}): `)) || currentConfig.TWITCH_CHANNEL;
    const clientId = (yield question(`Client ID (${currentConfig.TWITCH_CLIENT_ID || ''}): `)) || currentConfig.TWITCH_CLIENT_ID;
    const clientSecret = (yield question(`Client Secret (${currentConfig.TWITCH_CLIENT_SECRET || ''}): `)) || currentConfig.TWITCH_CLIENT_SECRET;
    const aiProvider = (yield question(`AI Provider (ollama/google) [default: ollama]: `)) || currentConfig.AI_PROVIDER || 'ollama';
    let apiKey = '';
    let aiModel = '';
    if (aiProvider === 'google') {
        apiKey = (yield question(`Google AI Studio API Key (${currentConfig.GOOGLE_API_KEY ? '*****' : 'Required'}): `)) || currentConfig.GOOGLE_API_KEY;
        if (!apiKey) {
            console.error('\n[!] Error: Google API Key is required when using Google provider.\n');
            process.exit(1);
        }
        // Fetch available models
        console.log('Fetching available models from Google AI Studio...');
        try {
            const { default: axios } = yield Promise.resolve().then(() => __importStar(require('axios')));
            const res = yield axios.get(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
            const models = (res.data.models || [])
                .filter((m) => { var _a; return (_a = m.supportedGenerationMethods) === null || _a === void 0 ? void 0 : _a.includes('generateContent'); })
                .map((m) => m.name.replace('models/', ''));
            if (models.length > 0) {
                console.log('\nAvailable Models:');
                models.forEach((m, i) => console.log(`${i + 1}. ${m}`));
                const selection = yield question(`\nSelect Model (1-${models.length}) [default: gemma-3-27b-it]: `);
                if (selection && parseInt(selection) > 0 && parseInt(selection) <= models.length) {
                    aiModel = models[parseInt(selection) - 1];
                }
                else {
                    aiModel = models.find((m) => m.includes('gemma-3-27b-it')) || models[0];
                }
                console.log(`Selected: ${aiModel}`);
            }
            else {
                console.log('No models found, using default.');
                aiModel = (yield question(`Google AI Model [default: gemma-3-27b-it]: `)) || currentConfig.AI_MODEL || 'gemma-3-27b-it';
            }
        }
        catch (err) {
            console.error('Failed to list models:', err.message);
            aiModel = (yield question(`Google AI Model [default: gemma-3-27b-it]: `)) || currentConfig.AI_MODEL || 'gemma-3-27b-it';
        }
    }
    else {
        aiModel = (yield question(`Ollama Model [default: gemma3:4b]: `)) || currentConfig.AI_MODEL || 'gemma3:4b';
    }
    if (!username || !channel || !clientId || !clientSecret) {
        console.error('\n[!] Error: Twitch credentials are required.\n');
        process.exit(1);
    }
    if (aiProvider === 'google' && !apiKey) {
        console.error('\n[!] Error: Google API Key is required when using Google provider.\n');
        process.exit(1);
    }
    const envContent = `
TWITCH_USERNAME=${username}
TWITCH_CHANNEL=${channel}
TWITCH_CLIENT_ID=${clientId}
TWITCH_CLIENT_SECRET=${clientSecret}
TWITCH_REDIRECT_URI=http://localhost:3000/auth/twitch/callback
PORT=3000
AI_PROVIDER=${aiProvider}
AI_MODEL=${aiModel}
GOOGLE_API_KEY=${apiKey}
`.trim();
    fs_1.default.writeFileSync(ENV_PATH, envContent);
    console.log('\n[Ok] Configuration saved to server/.env');
    console.log('\n=== Setup Complete ===');
    console.log('Please run "start_app.bat" to launch.');
    rl.close();
});
setup().catch(console.error);
