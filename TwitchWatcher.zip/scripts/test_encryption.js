"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const settings_1 = require("../store/settings");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
// Mock path for testing (optional, but store uses constant)
// We will just update and check file content
const main = () => __awaiter(void 0, void 0, void 0, function* () {
    console.log('[Test] Starting Encryption Test...');
    // 1. Save sensitive data
    console.log('[Test] Updating settings with secret...');
    const secret = "SuperSecretKey123";
    settings_1.settingsStore.update(s => (Object.assign(Object.assign({}, s), { twitch: Object.assign(Object.assign({}, s.twitch), { clientSecret: secret }) })));
    // 2. Read file directly to ensure it's encrypted
    const settingsPath = path_1.default.join(process.cwd(), 'settings.json');
    if (!fs_1.default.existsSync(settingsPath)) {
        console.error('[Test] FAIL: settings.json not found');
        return;
    }
    const rawContent = fs_1.default.readFileSync(settingsPath, 'utf-8');
    const parsed = JSON.parse(rawContent);
    if (parsed.twitch && parsed.twitch.clientSecret === secret) {
        console.error('[Test] FAIL: clientSecret found in plain text in settings.json!');
        console.log('File Content:', rawContent);
    }
    else {
        console.log('[Test] PASS: clientSecret is NOT plain text in file.');
        if (parsed.encryptedData) {
            console.log('[Test] PASS: Found encryptedData field.');
        }
        else {
            console.warn('[Test] WARN: No encryptedData field found? Structure:', parsed);
        }
    }
    // 3. Reload store and verify decryption
    console.log('[Test] Verifying Decryption via Store...');
    const loadedSettings = settings_1.settingsStore.get();
    if (loadedSettings.twitch.clientSecret === secret) {
        console.log('[Test] PASS: Store correctly decrypted the secret.');
    }
    else {
        console.error('[Test] FAIL: Store failed to decrypt secret. Got:', loadedSettings.twitch.clientSecret);
    }
    console.log('[Test] Test Complete.');
});
main();
