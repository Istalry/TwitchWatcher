"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
exports.config = {
    twitch: {
        username: process.env.TWITCH_USERNAME || '',
        channel: process.env.TWITCH_CHANNEL || '',
        clientId: process.env.TWITCH_CLIENT_ID || '',
        clientSecret: process.env.TWITCH_CLIENT_SECRET || '',
        redirectUri: process.env.TWITCH_REDIRECT_URI || 'http://localhost:3000/auth/twitch/callback',
    },
    server: {
        port: parseInt(process.env.PORT || '3000', 10),
    },
    ai: {
        provider: (process.env.AI_PROVIDER || 'ollama'),
        apiKey: process.env.GOOGLE_API_KEY || '',
        model: process.env.AI_MODEL || (process.env.AI_PROVIDER === 'google' ? 'gemma-2-27b-it' : 'gemma3:4b'),
    },
};
if (!exports.config.twitch.username || !exports.config.twitch.channel) {
    console.warn('WARNING: Initial Twitch config missing. Please run setup or configure .env');
}
