"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.aiService = exports.AIService = void 0;
const settings_1 = require("../../store/settings");
const googleProvider_1 = require("./googleProvider");
const ollamaProvider_1 = require("./ollamaProvider");
class AIService {
    constructor() {
        this.currentProvider = null;
        this.lastConfigSignature = '';
    }
    getProvider() {
        const settings = settings_1.settingsStore.get().ai;
        const signature = `${settings.provider}-${settings.model}-${settings.apiKey}`;
        // Re-initialize if config changed or first run
        if (!this.currentProvider || this.lastConfigSignature !== signature) {
            console.log(`[AIService] Switching AI Provider to ${settings.provider} (${settings.model})`);
            if (settings.provider === 'google') {
                this.currentProvider = new googleProvider_1.GoogleProvider();
                // GoogleProvider reads from config currently, we need to update it to read from settings
                // But since I haven't updated GoogleProvider yet, this might fail unless I fix GoogleProvider too.
                // Plan: Update providers to take config in constructor OR read from settingsStore directly.
                // Best approach: Read from settingsStore inside the providers.
            }
            else {
                this.currentProvider = new ollamaProvider_1.OllamaProvider();
            }
            this.lastConfigSignature = signature;
        }
        return this.currentProvider;
    }
    analyzeMessage(message_1) {
        return __awaiter(this, arguments, void 0, function* (message, history = []) {
            const provider = this.getProvider();
            return provider.analyzeMessage(message, history);
        });
    }
    healthCheck() {
        return __awaiter(this, void 0, void 0, function* () {
            const provider = this.getProvider();
            return provider.healthCheck();
        });
    }
}
exports.AIService = AIService;
exports.aiService = new AIService();
