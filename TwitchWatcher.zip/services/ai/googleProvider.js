"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleProvider = void 0;
const generative_ai_1 = require("@google/generative-ai");
const settings_1 = require("../../store/settings");
const promptBuilder_1 = require("./promptBuilder");
class GoogleProvider {
    constructor() {
        this.genAI = null;
        const settings = settings_1.settingsStore.get().ai;
        if (settings.apiKey) {
            this.genAI = new generative_ai_1.GoogleGenerativeAI(settings.apiKey);
            this.model = this.genAI.getGenerativeModel({
                model: settings.model,
                // NOTE: gemma-2/3 models may not support JSON mode natively via valid API
            });
        }
        else {
            console.warn('GoogleProvider used but no API Key provided in settings.');
        }
    }
    analyzeMessage(message_1) {
        return __awaiter(this, arguments, void 0, function* (message, history = []) {
            if (!this.model) {
                console.error('Google AI Model not initialized (missing API Key?)');
                return { flagged: false, reason: 'AI Config Error', suggestedAction: 'none' };
            }
            try {
                const prompt = (0, promptBuilder_1.buildModerationPrompt)(message, history);
                console.log('--- Sending to Google AI ---');
                console.log(prompt);
                const result = yield this.model.generateContent(prompt);
                const responseText = result.response.text();
                console.log('--- Google AI Response ---');
                console.log(responseText);
                // Clean up Markdown code blocks if present (e.g. ```json ... ```)
                const cleanJson = responseText.replace(/```json\n?|\n?```/g, '').trim();
                const parsed = JSON.parse(cleanJson);
                return {
                    flagged: parsed.flagged,
                    reason: parsed.reason,
                    suggestedAction: parsed.suggestedAction,
                };
            }
            catch (err) {
                console.error('Google AI Analysis Failed:', err);
                // Fail open
                return { flagged: false, reason: 'Analysis Failed', suggestedAction: 'none' };
            }
        });
    }
    healthCheck() {
        return __awaiter(this, void 0, void 0, function* () {
            // For Google, we can't easily "ping" without cost or complexity.
            // We assume healthy if API Key is present and model initialized.
            // A more robust check might be a dummy generation, but that costs quota.
            return !!this.model && !!this.genAI;
        });
    }
}
exports.GoogleProvider = GoogleProvider;
