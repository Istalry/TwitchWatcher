"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.twitchBot = exports.TwitchBot = void 0;
const tmi_js_1 = __importDefault(require("tmi.js"));
const axios_1 = __importDefault(require("axios"));
const settings_1 = require("../store/settings");
const history_1 = require("../store/history");
const analysisQueue_1 = require("./analysisQueue");
const authService_1 = require("./authService");
class TwitchBot {
    constructor() {
        this.client = null;
        this.broadcasterId = null; // Channel Owner
        this.moderatorId = null; // Bot Account (Token Owner)
        // Client is initialized in connect()
    }
    setupListeners() {
        if (!this.client)
            return;
        this.client.on('connected', (address, port) => {
            console.log(`Connected to ${address}:${port}`);
        });
        this.client.on('message', (channel, tags, message, self) => {
            if (self)
                return;
            this.handleMessage(tags, message);
        });
    }
    handleMessage(tags, message) {
        return __awaiter(this, void 0, void 0, function* () {
            const username = tags['display-name'] || tags.username || 'Unknown';
            console.log(`[${username}]: ${message}`);
            // store in history
            history_1.historyStore.addMessage(username, message);
            // get user history for context
            const user = history_1.historyStore.getUser(username);
            // Add to analysis queue (async)
            analysisQueue_1.analysisQueue.add(username, message);
        });
    }
    connect() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const settings = settings_1.settingsStore.get().twitch;
                // If setup not complete or missing credentials, don't crash, just log and wait
                if (!settings.username || !settings.channel) {
                    console.log('Twitch settings missing. Waiting for setup...');
                    return;
                }
                const token = yield authService_1.authService.getToken();
                if (!token) {
                    console.log('No valid Twitch token found. Waiting for authentication...');
                    // We rely on the Frontend Setup/Auth flow now.
                    return;
                }
                // Disconnect existing client if any (e.g. on re-auth)
                if (this.client) {
                    try {
                        yield this.client.disconnect();
                    }
                    catch (e) { /* ignore */ }
                }
                this.client = new tmi_js_1.default.Client({
                    options: { debug: true },
                    identity: {
                        username: settings.username,
                        password: `oauth:${token}`,
                    },
                    channels: [settings.channel],
                });
                this.setupListeners();
                yield this.client.connect();
                // 1. Fetch "Me" (Token Owner => Moderator ID)
                const meData = yield this.getHelixUser(); // No params = get self
                if (meData) {
                    this.moderatorId = meData.id;
                    console.log(`Authenticated as ${meData.display_name} (Moderator ID: ${this.moderatorId})`);
                }
                // 2. Fetch "Channel" (Broadcaster ID)
                if (settings.channel) {
                    // Channel name usually doesn't have # in API calls, but settings might
                    const channelName = settings.channel.replace('#', '');
                    const channelData = yield this.getHelixUser(channelName);
                    if (channelData) {
                        this.broadcasterId = channelData.id;
                        console.log(`Serving channel ${channelData.display_name} (Broadcaster ID: ${this.broadcasterId})`);
                    }
                }
            }
            catch (err) {
                console.error('Failed to connect to Twitch:', err);
            }
        });
    }
    // Pass nothing to get "Me", pass username to lookup someone else
    getHelixUser(username) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const token = yield authService_1.authService.getToken();
                if (!token)
                    return null;
                const settings = settings_1.settingsStore.get().twitch;
                let url = 'https://api.twitch.tv/helix/users';
                if (username) {
                    url += `?login=${username}`;
                }
                const res = yield axios_1.default.get(url, {
                    headers: {
                        'Client-ID': settings.clientId,
                        'Authorization': `Bearer ${token}`
                    }
                });
                return res.data.data[0] || null;
            }
            catch (err) {
                console.error(`Failed to lookup user ${username || 'self'}:`, err);
                return null;
            }
        });
    }
    simulateMessage(username, message) {
        return __awaiter(this, void 0, void 0, function* () {
            // Mock tmi tags
            const tags = {
                'display-name': username,
                username: username.toLowerCase(),
            };
            yield this.handleMessage(tags, message);
        });
    }
    banUser(username, reason) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            if (!this.broadcasterId || !this.moderatorId) {
                console.error('Cannot ban: IDs unknown');
                return;
            }
            try {
                const targetUser = yield this.getHelixUser(username);
                if (!targetUser) {
                    console.error(`Cannot ban: User ${username} not found`);
                    return;
                }
                const token = yield authService_1.authService.getToken();
                const settings = settings_1.settingsStore.get().twitch;
                yield axios_1.default.post(`https://api.twitch.tv/helix/moderation/bans?broadcaster_id=${this.broadcasterId}&moderator_id=${this.moderatorId}`, {
                    data: {
                        user_id: targetUser.id,
                        reason: reason
                    }
                }, {
                    headers: {
                        'Client-ID': settings.clientId,
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });
                history_1.historyStore.updateUserStatus(username, 'banned');
                console.log(`Banned ${username} for: ${reason}`);
            }
            catch (err) {
                console.error(`Failed to ban ${username}:`, ((_a = err.response) === null || _a === void 0 ? void 0 : _a.data) || err.message);
            }
        });
    }
    timeoutUser(username, duration, reason) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            if (!this.broadcasterId || !this.moderatorId) {
                console.error('Cannot timeout: IDs unknown');
                return;
            }
            try {
                const targetUser = yield this.getHelixUser(username);
                if (!targetUser) {
                    console.error(`Cannot timeout: User ${username} not found`);
                    return;
                }
                const token = yield authService_1.authService.getToken();
                const settings = settings_1.settingsStore.get().twitch;
                yield axios_1.default.post(`https://api.twitch.tv/helix/moderation/bans?broadcaster_id=${this.broadcasterId}&moderator_id=${this.moderatorId}`, {
                    data: {
                        user_id: targetUser.id,
                        duration: duration,
                        reason: reason
                    }
                }, {
                    headers: {
                        'Client-ID': settings.clientId,
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });
                history_1.historyStore.updateUserStatus(username, 'timed_out');
                console.log(`Timed out ${username} for ${duration}s: ${reason}`);
            }
            catch (err) {
                console.error(`Failed to timeout ${username}:`, ((_a = err.response) === null || _a === void 0 ? void 0 : _a.data) || err.message);
            }
        });
    }
    unbanUser(username) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            if (!this.broadcasterId || !this.moderatorId) {
                console.error('Cannot unban: IDs unknown');
                return;
            }
            try {
                const targetUser = yield this.getHelixUser(username);
                if (!targetUser) {
                    console.error(`Cannot unban: User ${username} not found`);
                    return;
                }
                const token = yield authService_1.authService.getToken();
                const settings = settings_1.settingsStore.get().twitch;
                yield axios_1.default.delete(`https://api.twitch.tv/helix/moderation/bans?broadcaster_id=${this.broadcasterId}&moderator_id=${this.moderatorId}&user_id=${targetUser.id}`, {
                    headers: {
                        'Client-ID': settings.clientId,
                        'Authorization': `Bearer ${token}`
                    }
                });
                history_1.historyStore.updateUserStatus(username, 'active');
                console.log(`Unbanned ${username}`);
            }
            catch (err) {
                console.error(`Failed to unban ${username}:`, ((_a = err.response) === null || _a === void 0 ? void 0 : _a.data) || err.message);
            }
        });
    }
    get isConnected() {
        var _a;
        return ((_a = this.client) === null || _a === void 0 ? void 0 : _a.readyState()) === 'OPEN';
    }
}
exports.TwitchBot = TwitchBot;
exports.twitchBot = new TwitchBot();
