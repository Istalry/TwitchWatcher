"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.analysisQueue = void 0;
const history_1 = require("../store/history");
const actionQueue_1 = require("../store/actionQueue");
const aiService_1 = require("./ai/aiService");
const crypto_1 = __importDefault(require("crypto"));
class AnalysisQueue {
    constructor() {
        this.queue = new Map();
        this.queueOrder = []; // Maintain order of users
        this.processing = false;
        this.lastProcessTime = 0;
        this.interval = null;
        console.log('AnalysisQueue initialized using aiService.');
        this.start();
    }
    add(username, message) {
        var _a;
        if (this.queue.has(username)) {
            // User already in queue, append message
            (_a = this.queue.get(username)) === null || _a === void 0 ? void 0 : _a.push(message);
        }
        else {
            // New user in queue
            this.queue.set(username, [message]);
            this.queueOrder.push(username);
        }
    }
    start() {
        if (this.interval)
            clearInterval(this.interval);
        // Check queue every 100ms, but enforce 2s generic rate limit in process()
        // actually checking every 500ms is probably fine
        this.interval = setInterval(() => this.process(), 500);
    }
    process() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.processing)
                return;
            if (this.queueOrder.length === 0)
                return;
            const now = Date.now();
            if (now - this.lastProcessTime < 2000) {
                return; // Rate limit: 1 request per 2 seconds
            }
            this.processing = true;
            const username = this.queueOrder.shift(); // Get first user
            if (!username) {
                this.processing = false;
                return;
            }
            const messages = this.queue.get(username);
            this.queue.delete(username); // Remove from batched map
            if (!messages || messages.length === 0) {
                this.processing = false;
                return;
            }
            try {
                // Batch messages
                // If multiple messages, maybe join them with newlines or periods?
                // "Hello world. Another message."
                const textToAnalyze = messages.join(' . ');
                // Get user history
                const user = history_1.historyStore.getUser(username);
                // Note: The history might NOT include current messages yet if we strictly added them to history BEFORE queueing.
                // But we passed them to queue. 
                // The historyStore is just context. The messages being analyzed are `textToAnalyze`.
                const historyContext = user ? user.messages.map(m => `[${new Date(m.timestamp).toLocaleTimeString()}] ${m.content}`) : [];
                // Run analysis
                const analysis = yield aiService_1.aiService.analyzeMessage(textToAnalyze, historyContext);
                if (analysis.flagged) {
                    console.log(`FLAGGED [${username}]: ${textToAnalyze} (${analysis.reason})`);
                    actionQueue_1.actionQueue.add({
                        id: crypto_1.default.randomUUID(),
                        username,
                        messageContent: textToAnalyze,
                        flaggedReason: analysis.reason || 'Unknown',
                        suggestedAction: analysis.suggestedAction === 'ban' ? 'ban' : 'timeout',
                        timestamp: Date.now(),
                        status: 'pending'
                    });
                }
                else {
                    console.log(`SAFE [${username}]: ${textToAnalyze}`);
                }
            }
            catch (err) {
                console.error(`Error processing queue for ${username}:`, err);
            }
            finally {
                this.lastProcessTime = Date.now();
                this.processing = false;
            }
        });
    }
}
exports.analysisQueue = new AnalysisQueue();
