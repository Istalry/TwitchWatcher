"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authService = void 0;
const axios_1 = __importDefault(require("axios"));
const settings_1 = require("../store/settings");
exports.authService = {
    // Generate the URL for the user to authorize on Twitch
    getAuthUrl: () => {
        const settings = settings_1.settingsStore.get().twitch;
        const scopes = [
            'chat:read',
            'chat:edit',
            'channel:moderate',
            'moderator:manage:banned_users',
            'moderator:manage:chat_messages'
        ];
        // Ensure redirect URI matches what we registered or default
        const redirectUri = 'http://localhost:3000/auth/twitch/callback';
        const params = new URLSearchParams({
            client_id: settings.clientId,
            redirect_uri: redirectUri,
            response_type: 'code',
            scope: scopes.join(' '),
        });
        return `https://id.twitch.tv/oauth2/authorize?${params.toString()}`;
    },
    // Exchange the authorization code for an access token
    exchangeCodeForToken: (code) => __awaiter(void 0, void 0, void 0, function* () {
        const settings = settings_1.settingsStore.get().twitch;
        const redirectUri = 'http://localhost:3000/auth/twitch/callback';
        try {
            const response = yield axios_1.default.post('https://id.twitch.tv/oauth2/token', null, {
                params: {
                    client_id: settings.clientId,
                    client_secret: settings.clientSecret,
                    code,
                    grant_type: 'authorization_code',
                    redirect_uri: redirectUri,
                },
            });
            const { access_token, refresh_token, expires_in, scope } = response.data;
            // Save to Secure Settings
            settings_1.settingsStore.updateTwitch({
                accessToken: access_token,
                refreshToken: refresh_token,
                // We don't store expiresAt explicitly in settings currently, maybe we should've added it?
                // For now, we'll rely on try/catch refresh flow or 401s if we don't track expiry.
                // Or I can add expiresAt to settings.ts interface. 
                // Let's assume we refresh on 401 or simply try refreshing if it fails.
                // But the previous logic had proactive refresh.
                // Let's stick to simple structure for now or maybe just force refresh if we suspect issues.
                // Actually, let's keep it simple. If 401, logic elsewhere should retry.
                // To keep this refactor safe, I will auto-refresh on startup or get access.
            });
            return access_token;
        }
        catch (error) {
            console.error('Error exchanging code for token:', error);
            throw error;
        }
    }),
    // Refresh the access token using the refresh token
    refreshAccessToken: () => __awaiter(void 0, void 0, void 0, function* () {
        const settings = settings_1.settingsStore.get().twitch;
        if (!settings.refreshToken) {
            throw new Error('No refresh token available');
        }
        try {
            const response = yield axios_1.default.post('https://id.twitch.tv/oauth2/token', null, {
                params: {
                    client_id: settings.clientId,
                    client_secret: settings.clientSecret,
                    grant_type: 'refresh_token',
                    refresh_token: settings.refreshToken,
                },
            });
            const { access_token, refresh_token } = response.data;
            settings_1.settingsStore.updateTwitch({
                accessToken: access_token,
                refreshToken: refresh_token || settings.refreshToken,
            });
            return access_token;
        }
        catch (error) {
            console.error('Error refreshing token:', error);
            throw error;
        }
    }),
    // Get a valid access token (refreshes if needed validation check fails? No, simplistic for now)
    getToken: () => __awaiter(void 0, void 0, void 0, function* () {
        const settings = settings_1.settingsStore.get().twitch;
        if (!settings.accessToken) {
            return null;
        }
        // Validate? Or just return. 
        // Real-world: Should check validation endpoint.
        // For this project: Return token. If it fails, the consumer should trigger refresh?
        // Or we can just validate it via Twitch API validation endpoint.
        try {
            yield axios_1.default.get('https://id.twitch.tv/oauth2/validate', {
                headers: { 'Authorization': `OAuth ${settings.accessToken}` }
            });
            return settings.accessToken;
        }
        catch (e) {
            // Token likely invalid/expired
            console.log('Token invalid or expired, refreshing...');
            try {
                return yield exports.authService.refreshAccessToken();
            }
            catch (refreshErr) {
                console.error('Failed to refresh token automatically.');
                return null;
            }
        }
    }),
    hasToken: () => {
        const settings = settings_1.settingsStore.get().twitch;
        return !!settings.accessToken;
    }
};
